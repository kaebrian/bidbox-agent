Export your n8n workflow here as bidbox-workflow.json (n8n: ... menu > Download).
